# CG2評価課題1 ReadMe

## <加点要素>
・三角形を動かす             SRTを使って1枚目の三角形を動かすことができた。

・Textureを貼る             uvChecker.pngを貼ることができた。

・DepthBufferの利用         三角形と三角形の前後関係ができた。  

・Textureの動的切り替え      uvChecker.png, monsterBall.png,stripe.pngの三つを変えられるようにした。

・三角形を利用した映像演出    2枚目の三角形で、左上から右下にかけて、流れ星のように降らして少し回転もかけて描画した。